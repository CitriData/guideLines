# Catálogo de componentes

Todos los componentes ya están definidos en `assets/template.html`. Este archivo
explica cuándo y cómo usar cada uno. Copia los bloques que necesites y elimina los
que no. El orden de las secciones es libre.

## Paleta (rebranding)

Los colores se controlan con 4 variables CSS en `:root`, al principio del `<style>`:

| Variable      | Uso                                          | Valor por defecto |
|---------------|----------------------------------------------|-------------------|
| `--ink`       | Cabecera, barras de sección, resumen, título | `#1a2b4a` (marino)|
| `--accent`    | Numeración, flechas, kicker                  | `#c05621` (naranja)|
| `--accent-2`  | Barras secundarias (`h2.alt`), bordes        | `#3b5a89` (azul)  |
| `--tree-bg`   | Fondo del bloque de árbol/código             | `#14213d`         |

Para adaptar la ficha a otra identidad corporativa, cambia solo estos 4 valores.

## Cabecera

- `.kicker` — texto pequeño en mayúsculas sobre el título (categoría/colección).
- `h1` — título principal.
- `.subtitle` — una línea que resume el documento.
- `.header-logo img` — logo arriba a la derecha. **Si no hay logo, elimina todo el
  `<div class="header-logo">`**; el texto ocupará el ancho completo.

## Barras de sección (`h2`)

- Barra oscura numerada: `<h2><span class="num">N</span> Título</h2>`.
- Barra azul sin número (para bloques "neutros" como un árbol o un anexo):
  `<h2 class="alt">Título</h2>`.

## Caja destacada (`.lead`)

Recuadro gris con borde izquierdo para la frase clave de una sección. Úsalo como
primer elemento tras la barra cuando quieras enfatizar una idea.

## Listas

`<ul><li>…</li></ul>` estándar. Para inline-code usa `<span class="mono">texto</span>`.

## Rejilla de tarjetas (`.grid2`)

Dos columnas de tarjetas. Reparte las tarjetas entre `.cell` izquierda y derecha
(no se colocan automáticamente: distribúyelas tú, alternando para equilibrar).
Cada `.card` lleva un `<h3>` (título) y un `<p>` (descripción breve).

## Etiquetas / píldoras (`.tag`)

Conjunto de categorías cortas. Colócalas todas dentro de un `<div class="tags">`,
pegadas sin espacios entre `</span>` y `<span>` para que el interletrado sea uniforme.

## Cadena / flujo (`.chain`)

Secuencia horizontal de pasos separados por flechas `<span class="arrow">&rsaquo;</span>`.
Ideal para pipelines o procesos. Mantén las etiquetas cortas (1-3 palabras).

## Árbol / bloque de código (`.tree`)

Bloque oscuro monoespaciado. Respeta la indentación literal (usa `├──`, `│`, `└──`).
- `<span class="c">nombre/</span>` resalta carpetas o claves.
- `<span class="subitems">comentario</span>` para anotaciones tenues a la derecha.
El contenido va en una sola línea HTML con saltos de línea reales (white-space: pre).

## Resumen (`.summary`)

Recuadro oscuro de cierre. Una o dos frases; resalta lo esencial con `<b>`.

## Pie (`.footer`)

- `.footer-logo img` — logo institucional a la izquierda. **Si no hay, elimina el
  `<div class="footer-logo">`.**
- `.footer-text` — atribución en negrita + fuentes/notas.

## Reglas de maquetación

- Formato A4, márgenes 18mm (arriba/abajo) y 16mm (izq/dcha), aplicados
  explícitamente en `render.py` vía el parámetro `margin` de `page.pdf()`
  (Playwright NO pone márgenes por defecto: sin este parámetro el contenido
  queda pegado al borde, lo que también se percibe como "fondo distinto").
  No elimines este parámetro al editar `render.py`.
- El contenido puede ocupar 1-2 páginas; no fuerces saltos salvo que se pida.
- Fuentes: sans-serif del sistema para el cuerpo, monoespaciada para código/árbol.
- No uses caracteres Unicode de subíndice/superíndice; usa `<sub>`/`<sup>` si hace falta.
- Mantén la densidad del ejemplo original: frases breves, mucho aire, poco relleno.
