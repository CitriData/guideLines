#!/usr/bin/env python3
"""Renderiza un HTML de ficha técnica a PDF (A4) con Playwright.

Uso:
    python render.py <entrada.html> <salida.pdf>

Los logos y demás imágenes deben estar en la MISMA carpeta que el HTML,
referenciados con rutas relativas (p. ej. src="header_logo.png").
"""
import sys
from pathlib import Path
from playwright.sync_api import sync_playwright


def render(html_path: str, pdf_path: str) -> None:
    html_uri = Path(html_path).resolve().as_uri()
    Path(pdf_path).parent.mkdir(parents=True, exist_ok=True)
    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page()
        page.goto(html_uri)
        page.pdf(
            path=pdf_path,
            format="A4",
            print_background=True,
            margin={"top": "18mm", "bottom": "18mm", "left": "16mm", "right": "16mm"},
        )
        browser.close()
    print(f"PDF generado: {pdf_path}")


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Uso: python render.py <entrada.html> <salida.pdf>")
        sys.exit(1)
    render(sys.argv[1], sys.argv[2])
