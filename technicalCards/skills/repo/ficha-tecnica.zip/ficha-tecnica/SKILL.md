---
name: ficha-tecnica
description: Crea fichas técnicas / infografías-resumen en PDF con una identidad visual concreta (cabecera con kicker+título, barras de sección oscuras numeradas en naranja, cajas destacadas, rejilla de tarjetas, píldoras/etiquetas, cadenas de flujo, bloques de árbol/código en oscuro, caja de resumen y pie con logos institucionales). Usa esta skill SIEMPRE que el usuario pida una "ficha técnica", una "ficha resumen", un "resumen visual", una "infografía", una "hoja resumen" o una "one-pager" en PDF, o cuando quiera convertir el contenido de un texto/imagen/documento en un PDF resumido con este estilo, aunque no nombre la skill explícitamente. También aplica cuando pida "otra ficha con este mismo look" o "una ficha como la anterior".
---

# Ficha técnica (PDF con estilo)

Genera fichas técnicas en PDF con un estilo visual coherente y profesional: útil
para resumir un concepto, una arquitectura, una guía o un documento en una o dos
páginas A4 bien maquetadas, con opción de branding institucional (logos en cabecera
y pie).

El estilo ya está encapsulado en una plantilla HTML que se renderiza a PDF con
Playwright. Tu trabajo es rellenar la plantilla con el contenido del usuario,
elegir los componentes adecuados y renderizar.

## Flujo de trabajo

1. **Reúne el contenido.** Puede venir de un texto, una imagen, un documento subido
   o de la propia conversación. Extrae el título, un subtítulo de una línea y las
   secciones principales. Si falta el título o la estructura no está clara,
   pregunta brevemente; si el contenido es evidente, procede.

2. **Copia la plantilla a la carpeta de trabajo** (los archivos de la skill suelen
   ser de solo lectura, así que trabaja sobre una copia). Localiza primero la
   carpeta de la skill y guárdala en una variable:
   ```bash
   SKILL_DIR=$(dirname "$(find /mnt/skills -name SKILL.md -path '*ficha-tecnica*' | head -1)")
   mkdir -p /home/claude/ficha_build
   cp "$SKILL_DIR/assets/template.html" /home/claude/ficha_build/ficha.html
   cp "$SKILL_DIR/assets/render.py"     /home/claude/ficha_build/render.py
   ```

3. **Lee `references/components.md`** para saber qué componente usar en cada caso
   (cabecera, barras de sección, cajas destacadas, tarjetas, etiquetas, cadena de
   flujo, árbol/código, resumen, pie). Contiene también la tabla de colores.

4. **Rellena `ficha.html`** editando la plantilla:
   - Sustituye kicker, título y subtítulo.
   - Crea una sección `h2` numerada por cada bloque de contenido. Elige el
     componente que mejor encaje (lista, tarjetas, etiquetas, flujo, árbol…).
   - Cierra con la caja `.summary`.
   - Elimina los bloques de componente que no uses.

5. **Logos institucionales (por defecto, en TODA ficha):**
   - Ya existen dos logos guardados de forma permanente en
     `assets/logos/`: `atd_fiware_logo.png` (cabecera — Aula de
     Transformación Digital FIWARE, 446×272px) y `uco_logo.png`
     (pie — escudo Universidad de Córdoba, 1162×610px).
   - **Úsalos siempre, en toda ficha, sin preguntar y sin necesidad de que
     el usuario los suba** — no son condicionales al tema del documento;
     representan la identidad institucional del usuario.
   - Cópialos a la carpeta de trabajo con los nombres que espera la
     plantilla:
     ```bash
     cp "$SKILL_DIR/assets/logos/atd_fiware_logo.png" /home/claude/ficha_build/header_logo.png
     cp "$SKILL_DIR/assets/logos/uco_logo.png"         /home/claude/ficha_build/footer_logo.png
     ```
   - Solo omite un logo (eliminando su `<div>` correspondiente) si el
     usuario pide explícitamente una ficha sin branding institucional, o
     si aporta logos distintos para sustituirlos.

6. **Renderiza a PDF:**
   ```bash
   cd /home/claude/ficha_build && python render.py ficha.html /mnt/user-data/outputs/<nombre>.pdf
   ```

7. **Verifica antes de entregar.** Rasteriza alguna página y mírala para confirmar
   que los logos cargan y la maqueta no se rompe:
   ```bash
   pdftoppm -png -r 90 /mnt/user-data/outputs/<nombre>.pdf /home/claude/preview
   ```
   Revisa `preview-1.png` (y `-2.png` si hay dos páginas). Corrige si algo se
   desborda o un logo no aparece.

8. **Presenta el PDF** con `present_files` y ofrece ajustes (colores corporativos,
   tamaño de logos, una sola página, etc.).

## Adaptar la identidad visual

Para rebrandear, cambia solo las 4 variables CSS de `:root` en el HTML
(`--ink`, `--accent`, `--accent-2`, `--tree-bg`). Ver la tabla en
`references/components.md`. No hace falta tocar el resto del CSS.

## Principios de estilo

- Frases breves y mucho espacio en blanco; la ficha resume, no reproduce.
- Una idea por sección; usa la caja `.lead` para destacar el mensaje central.
- Mantén las etiquetas y pasos de flujo cortos (1-3 palabras).
- Objetivo: 1-2 páginas A4. Si el contenido no cabe, prioriza y condensa antes que
  reducir tamaños de fuente.
- Respeta el copyright: resume con tus palabras, no copies textos largos de fuentes.

## Nota sobre dependencias

Requiere Playwright con Chromium (ya disponible en el entorno) y `pdftoppm`
(poppler-utils) para la verificación visual. El renderizado usa formato A4 con
fondos activados.
